from flask import Flask, render_template, request, jsonify
import re

app = Flask(__name__)


default_test_strings = ['sham@outlook.com', 'mini105@gmail.com', '12345', 'Dhivya']
default_regex_pattern = r"(?i)\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b|\b\d{5}\b|\b[A-Za-z]+\b"

@app.route("/")
def index():
    return render_template("index.html", default_test_strings=default_test_strings)

@app.route("/results", methods=["POST"])
def results():
    
    test_strings = request.form.getlist("test_string") or default_test_strings
    regex_pattern = request.form.get("regex_pattern", default_regex_pattern)
    
    matches = []
    for test_string in test_strings:
        match = re.findall(regex_pattern, test_string)
        if match:
            matches.extend(match)
    
    num_matches = len(matches)
    if num_matches > 0:
        result = f"Match\n\nRegex matches the input string. Found {num_matches} match{'es' if num_matches > 1 else ''}.\n\nFound matches: {matches}"
    else:
        result = "No match found."
    
    return render_template("results.html", result=result)

@app.route("/valid", methods=["POST"])
def valid():
    email = request.form.get("email")
    regex_pattern = r"(?i)\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b"
    match = re.match(regex_pattern, email)
    if  match:
        return render_template("email.html",uname=email)
    else:
        return("Not valid")
    

if __name__ == "__main__":
    app.run(host='0.0.0.0',port=5000)
